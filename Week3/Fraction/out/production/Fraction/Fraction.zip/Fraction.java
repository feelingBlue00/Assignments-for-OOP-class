public class Fraction {
    private int numerator;
    private int denominator = 1;

    /**
     * Constructor.
     */
    public Fraction(int numerator, int denominator) {
        this.numerator = numerator;
        setDenominator(denominator);
    }

    public int getNumerator() {
        return numerator;
    }

    public int getDenominator() {
        return denominator;
    }

    public void setNumerator(int numerator) {
        this.numerator = numerator;
    }

    /**
     * Set denominator.
     * @param denominator throw
     */
    public void setDenominator(int denominator) {
        if (denominator != 0) {
            this.denominator = denominator;
        }
    }

    /**
     * Calculate gcd of two integer.
     * @param numerator throw
     * @param denominator throw
     */
    public static int gcd(int numerator, int denominator) {
        if (numerator == 0 || denominator == 0) {
            return numerator + denominator;
        }

        while (numerator != denominator) {
            if (numerator > denominator) {
                numerator -= denominator;
            } else {
                denominator -= - numerator;
            }
        }
        return numerator;
    }

    /**
     * Calculate reduced fraction of two fraction.
     */
    public Fraction reduce() {
        int gcd = gcd(this.numerator, this.denominator);
        this.numerator = this.numerator / gcd;
        this.denominator = this.denominator / gcd;
        return this;
    }

    /**
     * Calculate sum of two fraction.
     * @param f throw
     * @return sum
     */
    public Fraction add(Fraction f) {
        this.numerator = this.numerator * f.denominator + this.denominator * f.numerator;
        this.denominator = this.denominator * f.denominator;
        return this;
    }

    /**
     * Calculate subtraction of two fraction.
     * @param f throw
     * @return subtraction
     */
    public Fraction subtract(Fraction f) {
        this.numerator = this.numerator * f.denominator - this.denominator * f.numerator;
        this.denominator = this.denominator * f.denominator;
        return this;
    }

    /**
     * Calculate multiplication of two fraction.
     * @param f throw
     * @return multiply
     */
    public Fraction multiply(Fraction f) {
        this.numerator = this.numerator * f.numerator;
        this.denominator = this.denominator * f.denominator;
        return this;
    }

    /**
     * Calculate division of two fraction.
     * @param f throw
     * @return division
     */
    public Fraction divide(Fraction f) {
        if (f.numerator != 0) {
            this.numerator = this.numerator * f.denominator;
            this.denominator = this.denominator * f.numerator;
        }
        return this;
    }

    /**
     * Check if two fraction were equal.
     * @param obj throw
     * @return true or false
     */
    public boolean equals(Object obj) {
        if (obj instanceof Fraction) {
            Fraction other = (Fraction) obj;
            if (this.numerator * other.denominator == other.numerator * this.denominator) {
                return true;
            }
            return false;
        }
        return false;
    }

    /**
     * Display method.
     */
    public void display() {
        System.out.println(this.numerator + "/" + this.denominator);
    }

    /**
     * For testing.
     * @param args throw
     */
    public static void main(String[] args) {
        Fraction fraction = new Fraction(3, 8);
        Fraction result = fraction.divide(new Fraction(2, 0));

        result.display();

    //    int result = gcd(2, 0);
    //    System.out.println(result);
    }

}

